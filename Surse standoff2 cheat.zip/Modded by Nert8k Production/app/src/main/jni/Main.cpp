#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include "Unity/Quaternion.h"
#include "Unity/Vector3.h"
#include "Includes/Obfuscate.h"
#include "Includes/Chams.h"
#pragma once
#include <sstream>
#include <codecvt>

extern "C" {
/*Time For Bools And all*/
    bool feature1 = false, feature2 = false, feature3 = false, feature18 = false, feature19 = false,feature20 = false, feature21 = false;
	bool drop, rec, antiban,noban = false;
	bool But, Leg, Dgon, Black, Star = false;
	bool Tanto, Dojo, Maf, Malac, Pearl, Tran, Flow = false;
	bool Flip, New1 = false;
	
	
    struct My_Patches {MemoryPatch Drop, Norec, antiban, antiban0, antiban1, antiban2, antiban3, antiban4,antiban5, antiban6, antiban7, antiban8,antiban9, antiban10,antiban11, antiban12, antiban13, antiban14,antiban15, antiban16, antiban17, antiban18,antiban19, antiban20,antiban21, antiban22, antiban23, antiban24,antiban25, antiban26, antiban27, antiban28,antiban29, antiban30,antiban31, antiban32;} hexPatches;
    const char *libName = "libil2cpp.so";
    /*Time for Menu         */
    JNIEXPORT jstring JNICALL
    Java_il2cpp_Main_apk(
        JNIEnv *env,
        jobject activityObject) {
    jstring str = env->NewStringUTF("      Modded By (yourmame) ");// никнейм
    return str;
}
    JNIEXPORT jstring JNICALL
    Java_il2cpp_Main_down(
        JNIEnv *env,
        jobject activityObject) {
    jstring str = env->NewStringUTF("Nert8k#8128");
        return str;
    }
    
    JNIEXPORT jstring JNICALL
Java_il2cpp_typefaces_Menu_gettype(
        JNIEnv *env,
        jobject activityObject) {
            
    jstring str = env->NewStringUTF("Font.ttf");
    return str;
}
    
    JNIEXPORT jobjectArray  JNICALL
Java_il2cpp_Main_getFeatures(
        JNIEnv *env,
        jobject activityObject) {
    jobjectArray ret;
    //text = CRASH
    //ButtonSwitch = HL1
    //Button = HL2
    //SeekBar = Example = SeekBar_Name_0_2
    //Hide icon = KIRA
    const char *features[] = {
		    "CRASH_FLIPKNIFE",//
			"HL2_New1",//40
		    "CRASH_Kunai",//none
			"HL2_Kunai Poison",//30
            "CRASH_Butterfly",//none
		    "HL1_Butterfly Legacy",//2
            "HL1_Butterfly Dragon Glass",//3
            "HL1_Butterfly BlackWindow",//4
            "HL1_Butterfly Starfall",//5
            "CRASH_Tanto",//none
			"HL1_Tanto Knife Dojo",//6
            "HL1_Tanto Knife Mafia",//7
            "HL1_Tanto Knife Malachite",//8
            "HL1_Tanto Knife Pearl Abyss",//9
            "HL1_Tanto Knife Transistor",//10
            "HL1_Tanto Knife Flow",//11
			"CRASH_SoftMenu",//none
			"HL1_DropKnife",//12
			"HL1_NoRecoril",//13
			"HL1_AntiBan[No Work]",//14
			"CRASH_Включайте оба антибана поcле выбора комманды. Если игра закончилась - выключите, чтобы не забанило до выбора - не врубать функции", //none
			"CRASH_Turn on both antibans after choosing a command. If the game is over, turn it off, so as not to be banned before choosing, do not turn on the function" ,//none
			"KIRA_Icon && Hide",//none
			"CRASH_If you have problem dm me Nert8k#8128",//
            };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 
JNIEXPORT void JNICALL
Java_il2cpp_Main_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint value) {
    switch (feature) {
		case 2:
        But = !But;
        Leg = !Leg;
        break;
        
        case 3:
        But = !But;
        Dgon = !Dgon;
        break;  
        
        case 4:
        But = !But;
        Black = !Black;
        break;
        
        case 5:
        But = !But;
        Star = !Star;
        break;
		
		case 6:
        Tanto = !Tanto;
        Dojo = !Dojo;
        break;
        
        case 7:
        Tanto = !Tanto;
        Maf = !Maf;
        break;
        
        case 8:
        Tanto = !Tanto;
        Malac = !Malac;
        break;
        
        case 9:
        Tanto = !Tanto;
        Pearl = !Pearl;
        break;
        
        case 10:
        Tanto = !Tanto;
        Tran = !Tran;
        break;
        
        case 11:
        Tanto = !Tanto;
        Flow = !Flow;
        break;
		
        case 12:
		drop = !drop;
		if (drop) {
			hexPatches.Drop.Modify();
		} else {
			hexPatches.Drop.Restore();
		}
		break;
		
		case 13:
	    rec = !rec;
		if (rec) {
			hexPatches.Norec.Modify();
		} else {
			hexPatches.Norec.Restore();
		}
		break;
	
		case 40:
			Flip = !Flip;
			New1 = !New1;
		case 14:
			antiban = !antiban;
            if (antiban) {
                hexPatches.antiban0.Modify();
                hexPatches.antiban1.Modify();
                hexPatches.antiban2.Modify();
                hexPatches.antiban3.Modify();
		        hexPatches.antiban4.Modify();
                hexPatches.antiban5.Modify();
                hexPatches.antiban6.Modify();
                hexPatches.antiban7.Modify();
		        hexPatches.antiban8.Modify();
                hexPatches.antiban9.Modify();
                hexPatches.antiban10.Modify();
                hexPatches.antiban11.Modify();
		        hexPatches.antiban12.Modify();
                hexPatches.antiban13.Modify();
                hexPatches.antiban14.Modify();
                hexPatches.antiban15.Modify();
		        hexPatches.antiban16.Modify();
                hexPatches.antiban17.Modify();
                hexPatches.antiban18.Modify();
                hexPatches.antiban19.Modify();
		        hexPatches.antiban20.Modify();
                hexPatches.antiban21.Modify();
                hexPatches.antiban22.Modify();
                hexPatches.antiban23.Modify();
		        hexPatches.antiban24.Modify();
                hexPatches.antiban25.Modify();
                hexPatches.antiban26.Modify();
                hexPatches.antiban27.Modify();
		        hexPatches.antiban28.Modify();
                hexPatches.antiban29.Modify();
                hexPatches.antiban30.Modify();
				hexPatches.antiban31.Modify();
				hexPatches.antiban32.Modify();
			} else {
                hexPatches.antiban0.Restore();
                hexPatches.antiban1.Restore();
                hexPatches.antiban2.Restore();
                hexPatches.antiban3.Restore();
		        hexPatches.antiban4.Restore();
                hexPatches.antiban5.Restore();
                hexPatches.antiban6.Restore();
                hexPatches.antiban7.Restore();
                hexPatches.antiban8.Restore();
                hexPatches.antiban9.Restore();
                hexPatches.antiban10.Restore();
                hexPatches.antiban11.Restore();
                hexPatches.antiban12.Restore();
                hexPatches.antiban13.Restore();
                hexPatches.antiban14.Restore();
                hexPatches.antiban15.Restore();
                hexPatches.antiban16.Restore();
                hexPatches.antiban17.Restore();
                hexPatches.antiban18.Restore();
                hexPatches.antiban19.Restore();
                hexPatches.antiban20.Restore();
                hexPatches.antiban21.Restore();
                hexPatches.antiban22.Restore();
                hexPatches.antiban23.Restore();
                hexPatches.antiban24.Restore();
                hexPatches.antiban25.Restore();
                hexPatches.antiban26.Restore();
                hexPatches.antiban27.Restore();
                hexPatches.antiban28.Restore();
                hexPatches.antiban29.Restore();
                hexPatches.antiban30.Restore();
				hexPatches.antiban31.Restore();
				hexPatches.antiban32.Restore();
               }
               break;
			 
			  
		
		
    }
}
JNIEXPORT jstring JNICALL
Java_il2cpp_typefaces_Menu_SliderString(
        JNIEnv *env,
        jobject clazz, jint feature, jint value) {
    // You must count your features from 0, not 1
    const char *SliderStr;
    if (feature == 6) {
        switch (value) {
            case 0:
                SliderStr = "Default";
                break;
            case 1:
                SliderStr = "2x";
                break;
            case 2:
                SliderStr = "4x";
                break;
            case 3:
                SliderStr = "8x";
                break;
            case 4:
                SliderStr = "12x";
                break;
            case 5:
                SliderStr = "24x";
                break;
        }
        return env->NewStringUTF(SliderStr);
    }
    if (feature == 7) {
        switch (value) {
            case 0:
                SliderStr = "Neck";
                break;
            case 1:
                SliderStr = "Hip";
                break;
            case 2:
                SliderStr = "Head";
                break;
        }
        return env->NewStringUTF(SliderStr);
    }
    if (feature == 8) {
        if (value <= 15){
            SliderStr = "Low";
        }
        else if (value >= 15 && value <= 35){
            SliderStr = "Medium";
        }
        else if (value >= 35){
            SliderStr = "High";
        }
        return env->NewStringUTF(SliderStr);
    }
    return env->NewStringUTF(NULL);
}
}
// ---------- Hooking ---------- //


void (*SendChat)(void *_this, int);
void (*old_MultiPlayerChat_Update)(void *instance);
void MultiPlayerChat_Update(void *instance) {
 if (instance != NULL) {
	 if (Flip){
		 SendChat(instance, 67);
	 }
      if (But) {
            SendChat(instance, 71);
      }
      if (Tanto) {
            SendChat(instance, 80);
            }
        old_MultiPlayerChat_Update(instance);
    }
    old_MultiPlayerChat_Update(instance);

}


void (*old_Skin)(void *instance, int lol2, int lol3);
void Skin(void *instance, int lol2, int lol3) {
    if (instance != NULL) {
        if (Leg) {
        	lol3 = 47502;
        }
        if (Dgon) {
        	lol3 = 47503;
        }
        if (Black) {
        	lol3 = 47504;
        }
         if (Star) {
        	lol3 = 47505;
        }
        if (Maf) {
        	lol3 = 138001;
        }
        if (Malac) {
        	lol3 = 138002;
        }
        if (Pearl) {
        	lol3 = 138003;
        }
        if (Tran) {
        	lol3 = 138004;
        }
        if (Flow) {
        	lol3 = 138005;
        }
		if (New1) {
			lol3 = 67001;
		}
        }
    old_Skin(instance, lol2, lol3);
}

bool (*old_get_IsInvincible)(void *instance);

bool get_IsInvincible(void *instance) {
    if (instance != NULL && feature2) {
        return true;
    }
    //LOGI("get_IsInvincible");
    return old_get_IsInvincible(instance);
}

void *hack_thread(void *) {
    
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
    setShader("_BumpMap");
    LogShaders();
    Wallhack();
    
	
	              //-------ВЫДАЧА--------
	SendChat = (void (*)(void *, int)) getAbsoluteAddress("libil2cpp.so", 0x844340);//set weapon
    MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0x846E04),//gameupdate
                   (void *) MultiPlayerChat_Update,
                   (void **) &old_MultiPlayerChat_Update); 
                   
    MSHookFunction((void *) getAbsoluteAddress("libil2cpp.so", 0xB92998), (void *) Skin,
                   (void **) &old_Skin);//setskin
				  
				   
				   //-------ФУНКЦИИ--------
    hexPatches.Drop = MemoryPatch::createWithHex("libil2cpp.so", 0xBE3E38, "01 00 A0 E3 1E FF 2F E1");
     
    hexPatches.Norec = MemoryPatch::createWithHex("libunity.so", 0x27E3DC, "804FC347");
    
	               //--------АНТИБАН--------
hexPatches.antiban0 = MemoryPatch::createWithHex("libil2cpp.so", 0x92B598, "1E FF 2F E1");
hexPatches.antiban1 = MemoryPatch::createWithHex("libil2cpp.so", 0x92B678, "1E FF 2F E1");
hexPatches.antiban2 = MemoryPatch::createWithHex("libil2cpp.so", 0x92B7EC, "1E FF 2F E1");
hexPatches.antiban3 = MemoryPatch::createWithHex("libil2cpp.so", 0x92B904, "1E FF 2F E1");
hexPatches.antiban4 = MemoryPatch::createWithHex("libil2cpp.so", 0x92BBBC, "1E FF 2F E1");
hexPatches.antiban5 = MemoryPatch::createWithHex("libil2cpp.so", 0x92BCD4, "1E FF 2F E1");
hexPatches.antiban6 = MemoryPatch::createWithHex("libil2cpp.so", 0x92BEB8, "1E FF 2F E1");
hexPatches.antiban7 = MemoryPatch::createWithHex("libil2cpp.so", 0x92BFD0, "1E FF 2F E1");
hexPatches.antiban8 = MemoryPatch::createWithHex("libil2cpp.so", 0x92C23C, "1E FF 2F E1");
hexPatches.antiban9 = MemoryPatch::createWithHex("libil2cpp.so", 0x92C338, "1E FF 2F E1");
hexPatches.antiban10 = MemoryPatch::createWithHex("libil2cpp.so", 0x92C47C, "1E FF 2F E1");
hexPatches.antiban11 = MemoryPatch::createWithHex("libil2cpp.so", 0x92C608, "1E FF 2F E1");
hexPatches.antiban12 = MemoryPatch::createWithHex("libil2cpp.so", 0x92C794, "1E FF 2F E1");
hexPatches.antiban13 = MemoryPatch::createWithHex("libil2cpp.so", 0x92C93C, "1E FF 2F E1");
hexPatches.antiban14 = MemoryPatch::createWithHex("libil2cpp.so", 0x92CA98, "1E FF 2F E1");
hexPatches.antiban15 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66928, "1E FF 2F E1");
hexPatches.antiban16 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66A08, "1E FF 2F E1");
hexPatches.antiban17 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66AFC, "1E FF 2F E1");
hexPatches.antiban18 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66BDC, "1E FF 2F E1");
hexPatches.antiban19 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66D74, "1E FF 2F E1");
hexPatches.antiban20 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66E28, "1E FF 2F E1");
hexPatches.antiban21 = MemoryPatch::createWithHex("libil2cpp.so", 0xB66FC0, "1E FF 2F E1");
hexPatches.antiban22 = MemoryPatch::createWithHex("libil2cpp.so", 0xB670B4, "1E FF 2F E1");
hexPatches.antiban23 = MemoryPatch::createWithHex("libil2cpp.so", 0xB67448, "1E FF 2F E1");
hexPatches.antiban24 = MemoryPatch::createWithHex("libil2cpp.so", 0xB67A44, "1E FF 2F E1");
hexPatches.antiban25 = MemoryPatch::createWithHex("libil2cpp.so", 0xB67D50, "1E FF 2F E1");
hexPatches.antiban26 = MemoryPatch::createWithHex("libil2cpp.so", 0xB68104, "1E FF 2F E1");
hexPatches.antiban27 = MemoryPatch::createWithHex("libil2cpp.so", 0xB685A0, "1E FF 2F E1");
hexPatches.antiban28 = MemoryPatch::createWithHex("libil2cpp.so", 0xB687D8, "1E FF 2F E1");
hexPatches.antiban29 = MemoryPatch::createWithHex("libil2cpp.so", 0x150212C, "1E FF 2F E1");
hexPatches.antiban30 = MemoryPatch::createWithHex("libil2cpp.so", 0x92B598, "1E FF 2F E1");
hexPatches.antiban31 = MemoryPatch::createWithHex("libil2cpp.so", 0xE99048, "1E FF 2F E1");
hexPatches.antiban32 = MemoryPatch::createWithHex("libil2cpp.so", 0x60AFC4, "1E FF 2F E1");




    // ---------- Hook ---------- //
    MSHookFunction((void *) getAbsoluteAddress(libName, 0xA62284), (void *) get_IsInvincible,
                   (void **) &old_get_IsInvincible);
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
